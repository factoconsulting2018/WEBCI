<?php

use yii\helpers\Html;

/** @var yii\web\View $this */

$this->title = 'Email templates';
?>

<div class="text-center py-5">
    <h1 class="display-6 mb-3">Muy pronto</h1>
    <p class="text-muted mb-4">Estamos trabajando en esta sección del panel administrativo.</p>
    <?= Html::a('Regresar al panel', ['site/index'], ['class' => 'btn btn-primary']) ?>
</div>


