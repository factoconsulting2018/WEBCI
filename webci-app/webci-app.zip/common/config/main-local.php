<?php

return [
    'components' => [
        'db' => [
            'class' => \yii\db\Connection::class,
            'dsn' => getenv('DB_DSN') ?: 'mysql:host=127.0.0.1;dbname=webci',
            'username' => getenv('DB_USER') ?: 'root',
            'password' => getenv('DB_PASSWORD') ?: '',
            'charset' => getenv('DB_CHARSET') ?: 'utf8mb4',
        ],
        'mailer' => [
            'class' => \yii\symfonymailer\Mailer::class,
            'viewPath' => '@common/mail',
            'useFileTransport' => getenv('MAIL_FILE_TRANSPORT') === 'true',
            'transport' => getenv('SMTP_DSN') ?: ('smtp://' . (getenv('SMTP_USERNAME') ? rawurlencode(getenv('SMTP_USERNAME')) : '')
                . (getenv('SMTP_PASSWORD') ? ':' . rawurlencode(getenv('SMTP_PASSWORD')) : '')
                . (getenv('SMTP_USERNAME') || getenv('SMTP_PASSWORD') ? '@' : '')
                . (getenv('SMTP_HOST') ?: 'mailhog')
                . ':' . (getenv('SMTP_PORT') ?: 1025)),
        ],
    ],
];
